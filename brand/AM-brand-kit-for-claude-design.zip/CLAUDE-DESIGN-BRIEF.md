# Brand brief for Claude Design: Abdelfattah M. (AM)

**Goal:** turn the starter identity in this package into a complete **brand identity document + brand guidelines + production assets** for the personal brand of Abdelfattah M. Aboulfoutoh.

**How to use this package:** attach this file, the `mascot/` folder (SVGs + PNGs + `tests.html`), the `logo/` folder (name wordmark), `design-tokens.json`, and the two reference images (see `reference/README.md`). Everything below is a starting point to build on, not a finished system. Where this brief says *open*, make a recommendation and flag it.

---

## 1. Who and what

| | |
|---|---|
| Name | **Abdelfattah Mohammed Sameer Aboulfoutoh**. Short forms: *Abdelfattah*, *AM*, *Abdelfattah M.* |
| Based in | Cairo, Egypt |
| Positioning | **Engineer. System Builder. Product Architect.** |
| One-liner | *Bridging physical infrastructure with digital solutions: designing structured, scalable systems for life, work, and technology.* |
| Domains | Engineering & construction management (project controls) · software & product development · data analysis & systems architecture |
| Role of the brand | The *signal* for a group of ventures: it builds the trust and audience that discovers Kyberia Tech and Peridot Holding. It is a personal brand, **not** a company brand. |
| Audience | Engineers, project/construction professionals, founders and builders, designers and developers, hiring managers and clients, in **English and Arabic** |
| Where it appears | abdelfattah.site (site + knowledge hub + free downloads), LinkedIn, GitHub, X, Instagram, Behance, Medium, ResearchGate, CV / cover letters, email, slides |
| Content pillars | Engineering insight · Product building · Systems thinking |

**Voice.** Use: systems, precision, building, engineering, compounding, endurance, maker. Avoid: influencer framing, hustle culture, growth-hack language. Tone is calm, exact, structured, confident without being loud. Copy is concise (Arabic runs 30–40% longer than English).

**Product context (for realistic mockups).** The site is a personal space combining a portfolio with wikis (Engineering, Developer, Design), research, a journey blog, free downloads (Claude skills/prompts, Notion & spreadsheet templates, website, CV and cover-letter templates) and behind-the-scenes guides.

## 2. Design language (what the logo and UI are based on)

Derived from the first reference image (a grid of black-and-white geometric logos):

- **Pure black and white**, one colour per mark. No gradients, shadows or outlines.
- **Basic geometry only**: semicircles, circles, rectangles, triangles. Every curve is a true circle; every edge is straight.
- **Negative space does the work**: the shape is carved, not drawn.
- **Heavy, blocky weight**; modular, grid-built; quiet and confident.
- Wordmarks are bold grotesque sans-serif, often tracked-out capitals.

The **second reference image** (a handwritten *mf.* monogram above a tracked capital name) was tried as a brush-signature monogram and then set aside: the owner prefers a **clean typographic logo set in the website font**.

UI language for the website, which the brand should also use: **circular frames for buttons and icons**, very simple 1.75-stroke line icons, pill-shaped text buttons, generous space, no decoration.

## 3. The brand as it exists now: a mascot of the owner

**Concept.** A flat, sticker-style **face-only** portrait of Abdelfattah, front view, traced from the owner's own reference: dark swept hair, thick brows, calm eyes, nose, mustache and a short mouth line, and a thick beard band that joins the hairline through the sideburns. Black and white only, thick black outline, white "sticker" edge, **yellow `#ffcc00`** as the brand background. There is a **sunglasses version** of every mascot file. The earlier 3/4 view and the bust were discarded. All text is **Tajawal** (English and Arabic).

**Source of truth.** `brand/mascot-art.mjs` (face and sunglasses), `brand/lockup.mjs` (every logo layout and its use case), `brand/build-mascot.mjs` (regenerates `mascot/`, `logos/`, site icons and the social image: `npm run brand`). The pose set is `brand/poses.mjs`, written by `brand/build-poses.mjs` (`npm run brand:poses`).

**The logo set (`logos/`, open `logos/index.html`).** Each logo has its own job; each exists in English and Arabic (right to left) and as SVG + 1600 px PNG.

| Logo | Files | Use |
|---|---|---|
| Mascot mark | `mascot/am-mascot*.svg`, `am-avatar*.svg`, `am-icon*.svg` | Avatars, app and site icons, stickers, anywhere a small square or circle is needed |
| Side lockup | `am-side-black/white(.ar).svg` | Website header, email signature, letterhead header, slide footers: one wide, short line |
| Name under the face | `am-under-yellow/white/black(.ar).svg` | Vertical formats: posters, covers, profile cards, banners, packaging |
| Mascot lettering | `am-lettering-yellow/white/black(.ar).svg` | Loud and friendly: video thumbnails, stickers, merch, stories. Name in the mascot's outline style: white fill, thick black outline, **black offset on light and yellow backgrounds, white offset on dark** |
| Sunglasses | `am-under-sun-yellow.svg`, `am-lettering-sun-yellow.svg`, `mascot/am-*-sun*.svg` | Relaxed or celebratory moments: social posts, launches, thumbnails. Never on formal documents |
| One-colour print | `print/am-mascot-print.svg`, `am-mascot-print-sun.svg` | Business card, letterhead, stamps: black on white, no edge, no yellow |

**Files in `mascot/`**

| File | Use |
|---|---|
| `am-mascot.svg` | Face with white sticker edge: dark backgrounds and transparent use. `-light` has a thin grey ring for white backgrounds (the site uses it in the light theme); `-flat` has no edge (yellow backgrounds, print). `-sun`, `-sun-light`, `-sun-flat` are the sunglasses versions |
| `am-avatar.svg`, `am-avatar-sun.svg` | Face on a yellow disc: social avatars |
| `am-icon.svg` | Simplified face on a yellow disc: favicon and app icon. The **16 and 32 px PNGs are hand-hinted pixel drawings** (`mascot-pixel.mjs`), not scaled vectors |
| `am-icon-maskable.svg` | Android **maskable** icon: full-bleed yellow, face inside the 80% safe zone (192/512 PNG) |
| `png/favicon.ico` | 16 and 32 hand-hinted, 48 vector (served at `/favicon.ico`) |
| `png/am-og-1200x630.png` | Open Graph image: side lockup on yellow |
| `poses/` | **Twelve poses** on one shared canvas, face only: *reactions* (calm, happy, wink, surprised, angry), *style* (sunglasses) and *work* (builder with hard hat, idea lightbulb, search magnifier, coding headphones, sketching pencil, launch rocket). SVG + 1024 px PNG each, `poses.html` contact sheet, `poses.json` names and uses. **Brand library only, not used on the website** |

**Print and downloads**

| Folder | Contents |
|---|---|
| `print/` | `am-mascot-print.svg` and `am-mascot-head-print.svg` (**one colour**, black on white, no sticker edge, no yellow). **Business card, two sides** (85 x 55 mm, 3 mm bleed, 5 mm safe margin, SVG + PDF + PNG): *front* is black with the mascot head and stacked name and a quiet ring pattern; *back* is white with name (Abdelfattah M. Aboulfoutoh, MSc.), title (Engineer & entrepreneur), phone, email, web (abdelfattah.site \| Kyberia.tech) and address (Maadi, Cairo, Egypt) over a faint ring pattern; **no logo or mascot in the pattern**. **A4 letterhead**: small header lockup, faint mascot watermark, footer with email, web, phone, address and page number; SVG + PDF + PNG, plus an **editable Word file** (`letterhead-a4.docx`, built by `brand/build-letterhead-docx.py`) where the header, watermark and footer repeat on every page and the page number is a live field. Text is outlined in the SVG and PDF |
| `covers/` | **Download-thumbnail system**: 1200 x 900 (4:3), black, a circular glyph frame with one yellow dot, the category name in Tajawal Bold, a matching pose at the bottom right. One cover per resource category (Claude, Notion, Spreadsheets, Website templates, CV and cover letters, Other) plus a blank "Your title here" template. Brand library only |

**Testing results (honest).**

| Test | Result |
|---|---|
| Single colour (black on white, white on black, on yellow, on grey) | Pass |
| Reversal on black (white sticker edge carries the shape) | Pass |
| Squint / blur and 1-bit threshold | Pass: beard, hair and face still read |
| Header size (46 px tall) | Pass |
| 32 px | Pass for the simplified icon |
| 16 px favicon | **Marginal**: reads as yellow disc, dark hair, white face, dark beard; no detail |

**Known weak spots:** on white backgrounds use the `-light` files (the plain white edge disappears); hands are drawn as palm, fingers and thumb (open, fist, thumbs-up).

## 4. Typography

| Role | Font | Notes |
|---|---|---|
| All text (UI, body, Arabic and Latin) | **Tajawal** (400 / 500 / 700) | Open Font License, self-hosted. Supports Arabic and Latin. |
| Display / headings / name / logo | **Tajawal** (700 / 800) | The same family for display, the name and the logo lettering (outlined in the files). Arabic and Latin share one design. |

Related brand (for context only): the **Kyberia** guidelines use Spline Sans (display), Satoshi (reading), Spline Sans Mono (labels) and IBM Plex Sans Arabic. The personal brand deliberately differs: black and white with yellow, Tajawal only.

## 5. Colour

Strictly black and white with **one** accent.

| Token | Value | Use |
|---|---|---|
| Black | `#000000` | Dark theme background, light theme text, logo |
| White | `#FFFFFF` | Light theme background, dark theme text, logo |
| Surface (dark / light) | `#0B0B0B` / `#F7F7F7` | Cards, drawers |
| Surface 2 | `#161616` / `#ECECEC` | Hover, chips |
| Muted text | `#A6A6A6` / `#595959` | Secondary text (≥ 4.5:1 on its background) |
| Line | `#252525` / `#E1E1E1` | Hairlines |
| Line strong | `#4D4D4D` / `#A8A8A8` | Circle and input borders |
| **Accent yellow** | **`#FFCC00`** | **Minimal use only** |

**Yellow rules.** Allowed: keyboard focus ring, the small "current page" dot, text-selection highlight, hover on a primary button, the favicon / app-icon disc, a single rule in social cards. **Never**: body text, large fills, text on white (fails contrast), more than one yellow element per view.

**Venture colours** (from the Kyberia brand guidelines; ventures show as grey until hovered on the site): Kyberia Tech `#FF2F92`, Kyberia Labs `#2D6BFF`, Kyberia Studios `#FF7A1A`. The three Kyberia lockups on the site are the **real vector logos taken from the guideline PDF** (never redrawn). Peridot Holding has no logo in that document, so it appears as text only, in `#7EB731` on hover.

## 6. UI components to document

Circular icon buttons (44 px, 1 px border, invert on hover), pill text buttons (48 px, primary = inverted, hover = yellow), search pill (58 px), chips, cards (large radius ~32 px, 1 px line), rows, side drawer (hub navigation, opens from the start edge, mirrored in RTL), two themes (Dark default, Light), full **RTL** (Arabic) via logical properties, motion ≤ 300 ms with reduced-motion respected, 44 px minimum targets, WCAG 2.2 AA (the site passes axe with 0 violations in both themes and languages).

Icons: 24-px grid, 1.75 stroke, round caps and joins, filled brand glyphs only for social networks. Tokens: `design-tokens.json`.

## 7. Deliverables requested

**A. Brand identity document + guidelines** (PDF and/or HTML), covering: brand story and positioning · voice and vocabulary (EN + AR) · logo anatomy, clear space (current: one cap-height on all sides), minimum sizes (wordmark 26 px on screen; AM badge below that), lockups, colour and one-colour rules, misuse (don'ts) · Arabic lockup rules · typography (Tajawal + Satoshi) with scale · colour system and accessibility pairs · iconography · layout and UI language (circular frames) · motion · imagery and diagram style (black/white, geometric, high-contrast) · how personal brand relates to Kyberia and Peridot (never mix colours; ventures appear grey until hovered) · templates guidance · dos and don'ts.

**B. Assets**

1. Final logo suite (SVG + PNG): every logo in the set in **English and Arabic**, one-colour, reversed; outlined text (no font dependencies). Offer a single-line (horizontal) variant if one is useful.
2. Favicon / app icon set including a **hand pixel-hinted 16×16 and 32×32** (the current auto-scaled one is soft at 16 px), `apple-touch-icon` 180, Android 192/512, maskable variants.
3. Social: avatars (LinkedIn, GitHub, X, Instagram, Behance, Medium, ResearchGate), banners (LinkedIn 1584×396, X 1500×500), GitHub social preview 1280×640, **Open Graph 1200×630** (a basic one exists), email signature.
4. Stationery: business card (85×55), letterhead, CV header block, cover-letter header, slide master (16:9) with title / section / content layouts, Notion page cover + icon set.
5. Download-thumbnail system: a consistent cover style for free downloads (Claude skills / prompts, Notion templates, spreadsheet templates, website templates, CV and cover-letter templates), 4:3, black/white, category glyphs in the circular-frame style.
6. A simple pattern / texture for backgrounds, built from the letterforms of the name.

## 8. Open items and risks (please address or flag)

Done: owner approved the likeness; Arabic lockup; hand-hinted 16/32 px favicon; light-background variants; maskable Android icons, .ico and web manifest; twenty poses (design, research, engineering, developer props); one-colour print mascot, business card and letterhead; download-thumbnail covers.

1. **Poses**: sixteen exist, with white shirt cuffs and simple hands. Still to do: a download-thumbnail system, engineering and developer props beyond the hard hat and laptop, and hand-polish of the hands. Keep the flat sticker style; props may use yellow, the default mascot keeps the tie as its only yellow.
2. **Arabic**: the lockup exists; design Arabic-context poses and check the lockup beside Arabic body copy.
4. **Peridot Holding**: stays text only by decision.
5. **Print**: files exist; send a physical proof before ordering (check the yellow against a Pantone Yellow-style swatch and the thin outlines at 85 x 55 mm).

## 9. Constraints

Black and white first; yellow minimal (the tie is the one yellow detail on the mascot); no gradients, drop shadows, 3D or glossy effects; no stock-photo styling; Arabic is a first-class language (RTL, Tajawal); everything must work in one colour and at small sizes; keep it **very simple**.

---

*Package contents:* `CLAUDE-DESIGN-BRIEF.md` (this file), `design-tokens.json`, `logo/` (SVG, PNG, tests), `build-logo.mjs` with `lib.mjs` and `mascot-art.mjs` (regenerate all logo files), `reference/README.md`.
